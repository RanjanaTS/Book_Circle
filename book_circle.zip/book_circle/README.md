# Book Circle

A web-based platform for buying, selling, and sharing books within a community. Users can post books for sale, browse available books, communicate with sellers, manage a shopping cart, and interact with an AI chatbot for assistance.

## Features

- **User Authentication**: Secure signup and login with session management
- **Book Management**: Post, edit, delete, and browse books with details like title, author, price, location, description, and ratings
- **Image Uploads**: Upload book images using Multer
- **Messaging System**: Private messaging between users for negotiations
- **Shopping Cart**: Add/remove books to/from cart for easy tracking
- **AI Chatbot**: Intelligent assistant for FAQs, book recommendations, and navigation help
- **Responsive Design**: Clean, user-friendly interface with CSS styling
- **Search & Filtering**: Browse books by location, price, and keywords

## Tech Stack

### Backend
- **Node.js** - Runtime environment
- **Express.js** - Web framework
- **MongoDB** - NoSQL database
- **Mongoose** - ODM for MongoDB
- **Express Session** - Session management
- **Connect Mongo** - Session store for MongoDB
- **bcryptjs** - Password hashing
- **Multer** - File upload handling

### Frontend
- **HTML5** - Markup
- **CSS3** - Styling
- **Vanilla JavaScript** - Client-side logic and API interactions

## Installation

1. **Clone the repository**:
   ```bash
   git clone <repository-url>
   cd book_circle
   ```

2. **Install dependencies**:
   ```bash
   npm install
   ```

3. **Set up environment variables**:
   Create a `.env` file in the root directory with:
   ```
   MONGO_URI=mongodb://127.0.0.1:27017/bookcircle
   SESSION_SECRET=your_secret_key_here
   PORT=3000
   ```

4. **Start MongoDB**:
   Ensure MongoDB is running locally or update `MONGO_URI` for a remote instance.

5. **Run the application**:
   ```bash
   npm start
   ```
   Or for development:
   ```bash
   npm run dev
   ```

6. **Access the app**:
   Open `http://localhost:3000` in your browser.

## Usage

### User Registration & Login
- Visit the homepage and sign up with a username and password
- Log in to access full features

### Posting Books
- Go to your Profile page
- Fill in book details (title, author, price, location, description, rating)
- Upload an image (optional)
- Click "Post Book"

### Browsing Books
- View all available books on the Home page
- Filter by price or search by keywords
- Click on books to view details and contact sellers

### Messaging
- Use the Messages page to view conversations
- Send messages to book owners for inquiries

### Shopping Cart
- Add books to your cart from the Home or Profile pages
- View and manage your cart items

### Chatbot
- Access the Chatbot page for AI assistance
- Ask questions about posting books, searching, or navigation

## API Endpoints

### Authentication
- `POST /signup` - User registration
- `POST /login` - User login
- `GET /me` - Get current user info
- `POST /logout` - Logout

### Books
- `GET /books` - Get all books
- `POST /books` - Create a new book (authenticated)
- `GET /books/mine` - Get user's own books (authenticated)
- `PUT /books/:id` - Edit a book (owner only)
- `DELETE /books/:id` - Delete a book (owner only)

### Cart
- `GET /cart` - Get user's cart (authenticated)
- `POST /cart/add/:bookId` - Add book to cart (authenticated)
- `DELETE /cart/remove/:bookId` - Remove book from cart (authenticated)

### Messaging
- `POST /messages` - Send a message (authenticated)
- `GET /messages/conversations` - Get user's conversations (authenticated)
- `GET /messages/thread/:userId` - Get message thread with a user (authenticated)

### Other
- `POST /chatbot` - Interact with AI chatbot
- `GET /users/:id` - Get user info by ID

## Project Structure

```
book_circle/
├── server.js              # Main server file
├── package.json           # Dependencies and scripts
├── .env                   # Environment variables
├── public/                # Static frontend files
│   ├── index.html         # Landing page
│   ├── login.html         # Login page
│   ├── home.html          # Main books page
│   ├── profile.html       # User profile and book management
│   ├── messages.html      # Messaging interface
│   ├── chatbot.html       # AI chatbot page
│   ├── style.css          # Global styles
│   └── script.js          # Client-side JavaScript
├── uploads/               # Uploaded book images
└── README.md              # This file
```

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Future Enhancements

- [ ] Email notifications for messages
- [ ] Advanced search filters (genre, condition, etc.)
- [ ] Payment integration
- [ ] Mobile app version
- [ ] Book rating and review system
- [ ] Admin panel for moderation

## Support

If you encounter any issues or have questions, please open an issue on the GitHub repository.
